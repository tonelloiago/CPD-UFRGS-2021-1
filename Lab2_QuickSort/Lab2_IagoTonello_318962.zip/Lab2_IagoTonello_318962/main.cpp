#include "header.h"

int main()
{
    system("exec rm -r saidas/*.txt");

    UnsortedArray newArray = UnsortedArray();

    return 0;

}